import pandas as pd 
from pandas.tseries.offsets import MonthEnd
from sqlalchemy import create_engine
from time import sleep
from binance import Client
apikey = 'TaTUeZHEGREyyZK1GpRJlEeLOIZbgfpwZ8tjNR4wVJB8IZKh8mHtVEclaateunJr'
secretkey = 'v6kpZIN5uyWmmQIIjF5b9lsMjDLWRhGhnWzX5JCaLtjo3TiZhQbjO73s7A2VyU4e'
client = Client(apikey,secretkey)

engine = create_engine('sqlite:///Cointest.db')
def getdata(symbol, start):
    end = str(pd.to_datetime(start)+ MonthEnd(0))
    frame = pd.DataFrame(client.get_historical_klines(symbol,'1m', start,end))
    frame = frame[[0,1,2,3,4]]
    frame.columns = ['Date', 'Open', 'High', 'Low', 'Close']
    frame.Date = pd.to_datetime(frame.Date, unit='ms')
    frame.set_index('Date', inplace=True)
    frame = frame.astype(float)
    return frame
coins = ('BTCUSDT', 'BNBUSDT', 'ETHUSDT', 'LTCUSDT','WINGUSDT')
daterange = pd.date_range('2023-01-01',pd.to_datetime('today'),freq='MS')
for coin in coins:
    for date in daterange:
        print(f'processing {date.month_name()} for {coin}...')
        df = getdata(coin,str(date))
        df.to_sql(coin,engine, if_exists='append',index=True)
        sleep(60)
    print(f'finished {coin}')
