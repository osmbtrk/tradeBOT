import pandas as pd
from sqlalchemy import create_engine

# Connect to the database
engine = create_engine('sqlite:///Cointest.db')

# Execute the SQL query to get the date range
query = "SELECT MIN(Date) AS MinDate, MAX(Date) AS MaxDate FROM ETHUSDT"
date_range = pd.read_sql(query, engine)

# Print the date range
print(f"Data range for ETHUSDT: {date_range['MinDate'][0]} - {date_range['MaxDate'][0]}")

